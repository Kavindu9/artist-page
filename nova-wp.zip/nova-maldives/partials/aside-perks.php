        <h3 class="font-title font-bold text-xl text-sapphire-blue-500 mb-4">Direct Booking Perks</h3>
        <ul class="list-disc  ml-3 marker:text-sapphire-blue-500  font text-lg space-y-2 text-sapphire-blue-900/70">
            <?php echo nova_get_option('booking_benefits'); ?>
        </ul>