<?php get_header(); ?>
<?php get_template_part('partials/home', 'hero'); ?>

<?php get_footer(); ?>